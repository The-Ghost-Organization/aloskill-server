import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

const envSchema = z.object({
  PORT: z.string().default(process.env.PORT as string),
  NODE_ENV: z.string().default(process.env.NODE_ENV as string),
  SECURE: z.enum(['development', 'production', 'test']).default('development'),
  JWT_SECRET: z
    .string()
    .min(32, 'JWT secret must be at least 32 characters')
    .default(process.env.JWT_SECRET as string),
  DATABASE_URL: z
    .url({ message: 'Invalid HTTP(S) URL' })
    .default(process.env.DATABASE_URL as string),
  IPN_VALIDATION_URL: z
    .url({ message: 'Invalid HTTP(S) URL of IPN' })
    .default(process.env.IPN_VALIDATION_URL as string),
  FRONTEND_URL: z
    .url({
      message: 'Invalid HTTP(S) URL',
      // protocol: /^http?$/i,
      // hostname: /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/,
    })
    .default(process.env.FRONTEND_URL as string),
  COOKIE_SECRET: z
    .string()
    .min(32, 'Cookie secret must be at least 32 characters')
    .default(process.env.COOKIE_SECRET as string),
  REFRESH_SECRET: z
    .string()
    .min(32, 'Cookie secret must be at least 32 characters')
    .default(process.env.REFRESH_SECRET as string),
  REFRESH_MAX_AGE: z.number().default(7 * 24 * 60 * 60 * 1000),
  ACCESS_MAX_AGE: z.number().default(12 * 60 * 60 * 1000),
  ACCESS_TOKEN_EXPIRY: z.string().default('12h'),
  REFRESH_TOKEN_EXPIRY: z.string().default('7d'),
  BCRYPT_ROUND: z.number().default(12),
  MAX_LOGIN_ATTEMP: z.number().default(5),
  LOCKOUT_DURATION: z
    .number('Lockout duration is required')
    .int('Lockout duration must be an integer')
    .min(1000, 'Lockout duration must be at least 1 second')
    .max(24 * 60 * 60 * 1000, 'Lockout duration cannot exceed 1 day')
    .default(15 * 60 * 1000),
  REDIS_HOST: z.string().default(process.env.REDIS_HOST as string),
  REDIS_PORT: z.string().default(process.env.REDIS_PORT as string),
  REDIS_PASSWORD: z.string().default(process.env.REDIS_PASSWORD as string),
  RESEND_API_KEY: z.string().default(process.env.RESEND_API_KEY as string),
  RESEND_FROM_EMAIL: z.string().default(process.env.RESEND_FROM_EMAIL as string),
  PHONE_KEY: z.string().default(process.env.PHONE_KEY as string),
  BUNNY_STREAM_API_KEY: z.string().default(process.env.BUNNY_STREAM_API_KEY as string),
  BUNNY_STREAM_TOKEN_AUTH_KEY: z
    .string()
    .default(process.env.BUNNY_STREAM_TOKEN_AUTH_KEY as string),
  BUNNY_STREAM_LIBRARY_ID: z.string().default(process.env.BUNNY_STREAM_LIBRARY_ID as string),
  BUNNY_STORAGE_ZONE_USERNAME: z
    .string()
    .default(process.env.BUNNY_STORAGE_ZONE_USERNAME as string),
  BUNNY_STORAGE_ZONE_PASSWORD: z
    .string()
    .default(process.env.BUNNY_STORAGE_ZONE_PASSWORD as string),
  BUNNY_PULL_ZONE: z.string().default(process.env.BUNNY_PULL_ZONE as string),
  SSLCOMMERCE_STORE_ID: z.string().default(process.env.SSLCOMMERCE_STORE_ID as string),
  SSLCOMMERCE_STORE_PASSWORD: z.string().default(process.env.SSLCOMMERCE_STORE_PASS as string),
  UDDOKTAPAY_URL: z.string().default(process.env.UDDOKTAPAY_URL as string),
  UDDOKTPAY_CHECKOUT_API: z.string().default(process.env.UDDOKTPAY_CHECKOUT_API as string),
  UDDOKTPAY_VERIFY_API: z.string().default(process.env.UDDOKTPAY_VERIFY_API as string),
  UDDOKTPAY_RETURN_API: z.string().default(process.env.UDDOKTPAY_RETURN_API as string),
  UDDOKTAPAY_WEBHOOK_URL: z.url().optional(),
  STEADFAST_BASE_URL: z
    .url({ message: 'Invalid Steadfast base URL' })
    .default('https://portal.packzy.com/api/v1'),
  STEADFAST_API_KEY: z.string().default(process.env.STEADFAST_API_KEY ?? ''),
  STEADFAST_SECRET_KEY: z.string().default(process.env.STEADFAST_SECRET_KEY ?? ''),
  SHIPPING_INSIDE_DHAKA: z.coerce.number().nonnegative().default(70),
  SHIPPING_DHAKA_SUBURBAN: z.coerce.number().nonnegative().default(100),
  SHIPPING_OUTSIDE_DHAKA: z.coerce.number().nonnegative().default(130),
  SHIPPING_BASE_WEIGHT_KG: z.coerce.number().positive().default(.5),
  SHIPPING_EXTRA_PER_KG: z.coerce.number().nonnegative().default(20),

  // EPS_USERNAME: z.string().default(process.env.EPS_USERNAME as string),
  // EPS_PASSWORD: z.string().default(process.env.EPS_PASSWORD as string),
  // EPS_HASH_KEY: z.string().default(process.env.EPS_HASH_KEY as string),
  // EPS_MERCHANT_ID: z.string().default(process.env.EPS_MERCHANT_ID as string),
  // EPS_STORE_ID: z.string().default(process.env.EPS_STORE_ID as string),
  // EPS_SANDBOX: z.coerce.boolean().default(process.env.EPS_SANDBOX === 'true'),

  EPS_USERNAME: z.string().min(1, 'EPS_USERNAME is required'),
  EPS_PASSWORD: z.string().min(1, 'EPS_PASSWORD is required'),
  EPS_HASH_KEY: z.string().min(20, 'EPS_HASH_KEY is invalid'),
  EPS_MERCHANT_ID: z.string().uuid('EPS_MERCHANT_ID must be a UUID'),
  EPS_STORE_ID: z.string().uuid('EPS_STORE_ID must be a UUID'),
  EPS_SANDBOX: z.preprocess(
    value => value === true || value === 'true',
    z.boolean()
  ).default(true),
});

export const config = envSchema.parse(process.env);

export type Config = z.infer<typeof envSchema>;
