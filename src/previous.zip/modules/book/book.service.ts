/* eslint-disable @typescript-eslint/no-unnecessary-condition */
/* eslint-disable @typescript-eslint/no-base-to-string */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { Decimal } from '@prisma/client/runtime/client';
import { type Request } from 'express';
import * as XLSX from 'xlsx';
import { executeDbOperation } from '../../config/database.js';
import { ApplicationStatus, BookFormat, BookStatus, OrderStatus } from '../../generated/enums.js';
import {
  CreateBookBodySchema,
  type CreateBookInput,
  type UploadBookPayload,
} from './book.validation.js';

type DatabaseClient = Parameters<Parameters<typeof executeDbOperation>[0]>[0];
type TransactionArgument = Parameters<DatabaseClient['$transaction']>[0];
type TransactionClient = TransactionArgument extends (tx: infer T) => unknown ? T : never;

const getAuthorizedOwner = async (tx: TransactionClient, email: string) => {
  const owner = await tx.user.findUnique({
    where: { email, deletedAt: null, status: 'ACTIVE' },
    include: { assignedRole: true },
  });
  if (!owner) {
    throw new Error('Unauthorized: Owner not found.');
  }
  if (!owner.assignedRole.some(r => r.role === 'ADMIN' || r.role === 'INSTRUCTOR')) {
    throw new Error('Security Violation: Only Admins or Instructors can upload books.');
  }
  return owner;
};

const getAuthorizedAdmin = async (tx: TransactionClient, email?: string) => {
  if (!email) {
    throw new Error('Unauthorized: User not authenticated.');
  }
  const admin = await tx.user.findUnique({
    where: { email, deletedAt: null, status: 'ACTIVE' },
    include: { assignedRole: true },
  });
  if (!admin?.assignedRole.some(role => role.role === 'ADMIN')) {
    throw new Error('Security Violation: Only admins can perform this action.');
  }
  return admin;
};

const toSlug = (value: string) =>
  value
    .trim()
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\p{Letter}\p{Number}]+/gu, '-')
    .replace(/^-+|-+$/g, '');

const uniqueAuthorSlug = async (tx: TransactionClient, name: string, excludeId?: string) => {
  const base = toSlug(name) || 'author';
  let slug = base;
  let suffix = 2;

  while (
    await tx.bookAuthor.findFirst({
      where: {
        slug,
        ...(excludeId ? { id: { not: excludeId } } : {}),
      },
      select: { id: true },
    })
  ) {
    slug = `${base}-${suffix++}`;
  }

  return slug;
};

const ensureInstructorAuthorProfile = async (
  tx: TransactionClient,
  owner: Awaited<ReturnType<typeof getAuthorizedOwner>>
) => {
  const instructor = await tx.instructorProfile.findUnique({
    where: { userId: owner.id },
    select: {
      id: true,
      displayName: true,
      bio: true,
      website: true,
      deletedAt: true,
      user: { select: { avatarUrl: true } },
    },
  });

  if (!instructor || instructor.deletedAt) {
    throw new Error('Instructor profile not found.');
  }

  const existing = await tx.bookAuthor.findUnique({
    where: { instructorProfileId: instructor.id },
  });
  if (existing) {
    return existing;
  }

  const slug = await uniqueAuthorSlug(tx, instructor.displayName);
  return await tx.bookAuthor.create({
    data: {
      instructorProfileId: instructor.id,
      name: instructor.displayName,
      slug,
      bio: instructor.bio,
      websiteUrl: instructor.website,
      photoUrl: instructor.user.avatarUrl,
      isActive: true,
    },
  });
};

const resolveBookAuthor = async (
  tx: TransactionClient,
  owner: Awaited<ReturnType<typeof getAuthorizedOwner>>,
  data: CreateBookInput
) => {
  const isInstructor = owner.assignedRole.some(role => role.role === 'INSTRUCTOR');

  if (isInstructor) {
    const author = await ensureInstructorAuthorProfile(tx, owner);
    return { authorName: author.name, authorProfileId: author.id };
  }

  if (data.authorProfileId) {
    const author = await tx.bookAuthor.findFirst({
      where: { id: data.authorProfileId, deletedAt: null, isActive: true },
    });
    if (!author) {
      throw new Error('Selected author profile was not found.');
    }
    return { authorName: author.name, authorProfileId: author.id };
  }

  const existingAuthor = await tx.bookAuthor.findFirst({
    where: {
      name: { equals: data.author.trim(), mode: 'insensitive' },
      deletedAt: null,
      isActive: true,
    },
  });

  return {
    authorName: existingAuthor?.name ?? data.author.trim(),
    authorProfileId: existingAuthor?.id ?? null,
  };
};

const createBook = async (
  tx: TransactionClient,
  owner: Awaited<ReturnType<typeof getAuthorizedOwner>>,
  data: CreateBookInput
) => {
  const category = await tx.bookCategory.findUnique({ where: { name: data.category } });
  if (!category) {
    throw new Error(`Invalid category: ${data.category}.`);
  }

  const resolvedAuthor = await resolveBookAuthor(tx, owner, data);

  const newBook = await tx.book.create({
    data: {
      title: data.title,
      author: resolvedAuthor.authorName,
      authorProfileId: resolvedAuthor.authorProfileId,
      publisher: data.publisher,
      publishYear: Number(data.publishYear),
      ratings: new Decimal(data.ratings),
      translator: data.translator,
      editor: data.editor,
      description: data.description,
      purchaseCost: new Decimal(data.purchaseCost ?? 0),
      physicalRegularPrice: new Decimal(data.physicalRegularPrice ?? 0),
      physicalSalePrice: new Decimal(data.physicalSalePrice ?? 0),
      digitalRegularPrice: new Decimal(data.digitalRegularPrice ?? 0),
      digitalSalePrice: new Decimal(data.digitalSalePrice ?? 0),
      stock: data.stock,
      language: data.language,
      coverImage: data.coverImageUrl,
      isbn: data.isbn,
      edition: data.edition,
      pages: data.pages,
      weight: data.weight,
      metaKeywords: data.metaKeywords,
      metaDescription: data.metaDescription,
      ownerId: owner.id,
      categoryId: category.id,
      status: data.status === 'DRAFT' ? BookStatus.DRAFT : BookStatus.PENDING,
      formats: data.formats.map(f =>
        f === 'Hardcover' ? BookFormat.HARDCOVER : BookFormat.E_BOOK
      ),
      files: {
        create: data.files.map(file => ({
          name: file.name,
          url: file.url,
          fileType: file.fileType,
        })),
      },
    },
    include: { files: true },
  });
  await tx.auditLog.create({
    data: {
      userId: owner.id,
      action: 'BOOK_CREATED',
      entityType: 'BOOK',
      entityId: newBook.id,
      changesAfter: JSON.parse(JSON.stringify(newBook)),
      ipAddress: 'captured-from-request',
    },
  });
  return newBook;
};

const getBooksCategories = async () => {
  const categories = await executeDbOperation(async prisma => {
    return await prisma.bookCategory.findMany({
      select: {
        id: true,
        name: true,
      },
    });
  }, 'Get Books Categories');

  return categories;
};

const uploadBook = async (req: Request) => {
  const data = req.body as UploadBookPayload['body'];
  const user = req.user;
  if (!user.email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  const upload = await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      const owner = await getAuthorizedOwner(tx, user.email);
      return createBook(tx, owner, data);
    });
  }, 'Upload Book');

  return upload.id;
};

const text = (value: unknown): string | undefined => {
  if (value === null || value === undefined) {
    return undefined;
  }

  const normalized = String(value).trim();
  if (!normalized || ['undefined', 'null'].includes(normalized.toLowerCase())) {
    return undefined;
  }

  return normalized;
};

const list = (value: unknown): string[] =>
  String(value ?? '')
    .split(',')
    .map(item => item.trim())
    .filter(Boolean);

type MediaUrlMap = Record<string, string>;

const normalizeMediaKey = (value: unknown): string | undefined => {
  const raw = text(value);
  if (!raw) {
    return undefined;
  }

  return raw.replace(/\\/g, '/').split('/').pop()?.trim().toLowerCase() ?? undefined;
};

const normalizeHttpsUrl = (value: unknown): string | undefined => {
  const raw = text(value)?.replace(/^["']|["']$/g, '');
  if (!raw) {
    return undefined;
  }

  let normalized = raw;
  if (normalized.startsWith('//')) {
    normalized = `https:${normalized}`;
  } else if (/^[\w.-]+\.b-cdn\.net\//i.test(normalized)) {
    normalized = `https://${normalized}`;
  }

  try {
    const url = new URL(normalized);
    return url.protocol === 'https:' ? url.href : undefined;
  } catch {
    return undefined;
  }
};

const mappedMediaUrl = (mediaUrls: MediaUrlMap, fileName: unknown): string | undefined => {
  const key = normalizeMediaKey(fileName);
  return key ? normalizeHttpsUrl(mediaUrls[key]) : undefined;
};

const mediaFileReference = (
  fileNameColumn: unknown,
  legacyUrlColumn: unknown
): string | undefined => {
  const explicitFileName = text(fileNameColumn);
  if (explicitFileName) {
    return explicitFileName;
  }

  // Backward compatibility: an old sheet may contain a filename in a URL column.
  const legacyValue = text(legacyUrlColumn);
  return legacyValue && !normalizeHttpsUrl(legacyValue) ? legacyValue : undefined;
};

const resolveMediaUrl = (
  directUrl: unknown,
  fileName: unknown,
  mediaUrls: MediaUrlMap
): string | undefined => {
  const directHttpsUrl = normalizeHttpsUrl(directUrl);
  if (directHttpsUrl) {
    return directHttpsUrl;
  }

  const reference = mediaFileReference(fileName, directUrl);
  return mappedMediaUrl(mediaUrls, reference);
};

const files = (row: Record<string, unknown>, mediaUrls: MediaUrlMap): CreateBookInput['files'] => {
  const result: CreateBookInput['files'] = [];
  const previewUrl = resolveMediaUrl(row.previewFileUrl, row.previewPdfFile, mediaUrls);
  const ebookUrl = resolveMediaUrl(row.ebookFileUrl, row.ebookPdfFile, mediaUrls);

  if (previewUrl) {
    result.push({
      name: text(row.previewFileName) ?? text(row.previewPdfFile) ?? 'Preview',
      url: previewUrl,
      fileType: 'PREVIEW',
    });
  }

  if (ebookUrl) {
    result.push({
      name: text(row.ebookFileName) ?? text(row.ebookPdfFile) ?? 'E-Book',
      url: ebookUrl,
      fileType: 'EBOOK',
    });
  }

  return result;
};

const excelRowToBook = (row: Record<string, unknown>, mediaUrls: MediaUrlMap): unknown => ({
  title: text(row.title),
  author: text(row.author),
  translator: text(row.translator),
  editor: text(row.editor),
  publisher: text(row.publisher),
  publishYear: text(row.publishYear),
  ratings: text(row.ratings),
  description: text(row.description),
  purchaseCost: row.purchaseCost,
  physicalRegularPrice: row.physicalRegularPrice,
  physicalSalePrice: row.physicalSalePrice === '' ? undefined : row.physicalSalePrice,
  digitalRegularPrice: row.digitalRegularPrice === '' ? undefined : row.digitalRegularPrice,
  digitalSalePrice: row.digitalSalePrice === '' ? undefined : row.digitalSalePrice,
  stock: row.stock === '' ? undefined : row.stock,
  isbn: text(row.isbn),
  edition: text(row.edition),
  pages: row.pages,
  weight: row.weight === '' ? undefined : row.weight,
  language: text(row.language),
  category: text(row.category),
  formats: list(row.formats),
  status: text(row.status) ?? 'PENDING',
  metaKeywords: text(row.metaKeywords),
  metaDescription: text(row.metaDescription),

  // CreateBookBodySchema receives only a final HTTPS URL here.
  coverImageUrl: resolveMediaUrl(row.coverImageUrl, row.coverImageFile, mediaUrls),
  files: files(row, mediaUrls),
});

const parseMediaUrls = (value: unknown): MediaUrlMap => {
  if (!value) {
    return {};
  }

  let parsed: unknown = value;
  if (typeof value === 'string') {
    try {
      parsed = JSON.parse(value);
    } catch {
      throw new Error('The mediaUrls field contains invalid JSON.');
    }
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('The mediaUrls field must be a filename-to-URL object.');
  }

  const entries = Object.entries(parsed as Record<string, unknown>);
  if (entries.length > 1500) {
    throw new Error('A maximum of 1,500 media files is allowed.');
  }

  const result: MediaUrlMap = {};
  for (const [fileName, rawUrl] of entries) {
    const cleanName = normalizeMediaKey(fileName);
    const cleanUrl = normalizeHttpsUrl(rawUrl);

    if (!cleanName || !cleanUrl) {
      throw new Error(`Invalid Bunny media mapping for "${fileName || 'unknown file'}".`);
    }

    result[cleanName] = cleanUrl;
  }

  return result;
};

const bulkUploadBooks = async (req: Request) => {
  const userEmail = req.user.email;
  if (!userEmail) {
    throw new Error('Unauthorized: User not authenticated.');
  }
  if (!req.file?.buffer) {
    throw new Error('An Excel file is required in the "file" field.');
  }

  const mediaUrls = parseMediaUrls(req.body?.mediaUrls);
  const workbook = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: false });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  if (!sheet) {
    throw new Error('The workbook must contain at least one worksheet.');
  }

  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
  if (!rows.length) {
    throw new Error('The first worksheet does not contain any book rows.');
  }
  if (rows.length > 500) {
    throw new Error('A maximum of 500 books can be imported at once.');
  }

  const results: Array<{
    row: number;
    success: boolean;
    bookId?: string;
    errors?: Array<{ field: string; message: string }>;
  }> = [];

  for (const [index, row] of rows.entries()) {
    const rowNumber = index + 2;
    const mediaChecks = [
      {
        field: 'coverImageUrl',
        excelColumn: 'coverImageFile',
        required: true,
        reference: mediaFileReference(row.coverImageFile, row.coverImageUrl),
        directUrl: normalizeHttpsUrl(row.coverImageUrl),
      },
      {
        field: 'files.previewUrl',
        excelColumn: 'previewPdfFile',
        required: false,
        reference: mediaFileReference(row.previewPdfFile, row.previewFileUrl),
        directUrl: normalizeHttpsUrl(row.previewFileUrl),
      },
      {
        field: 'files.ebookUrl',
        excelColumn: 'ebookPdfFile',
        required: false,
        reference: mediaFileReference(row.ebookPdfFile, row.ebookFileUrl),
        directUrl: normalizeHttpsUrl(row.ebookFileUrl),
      },
    ] as const;

    const mediaErrors: Array<{ field: string; message: string }> = [];
    for (const check of mediaChecks) {
      if (check.directUrl) {
        continue;
      }

      if (!check.reference) {
        if (check.required) {
          mediaErrors.push({
            field: check.field,
            message: `Enter the exact selected image filename in ${check.excelColumn}.`,
          });
        }
        continue;
      }

      if (!mappedMediaUrl(mediaUrls, check.reference)) {
        mediaErrors.push({
          field: check.field,
          message: `No uploaded media file matched "${check.reference}" from ${check.excelColumn}.`,
        });
      }
    }

    if (mediaErrors.length) {
      results.push({ row: rowNumber, success: false, errors: mediaErrors });
      continue;
    }

    const parsed = CreateBookBodySchema.safeParse(excelRowToBook(row, mediaUrls));
    if (!parsed.success) {
      results.push({
        row: rowNumber,
        success: false,
        errors: parsed.error.issues.map(issue => ({
          field: issue.path.join('.') || 'row',
          message: issue.message,
        })),
      });
      continue;
    }

    try {
      const book = await executeDbOperation(
        prisma =>
          prisma.$transaction(async tx => {
            const owner = await getAuthorizedOwner(tx, userEmail);
            return createBook(tx, owner, parsed.data);
          }),
        `Bulk Upload Book - Row ${rowNumber}`
      );
      results.push({ row: rowNumber, success: true, bookId: book.id });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Import failed.';
      results.push({
        row: rowNumber,
        success: false,
        errors: [{ field: 'row', message: message.replace(/\u001B\[[0-?]*[ -\/]*[@-~]/g, '') }],
      });
    }
  }

  const imported = results.filter(result => result.success).length;
  return { total: rows.length, imported, failed: rows.length - imported, results };
};

const updateBook = async (req: Request) => {
  const { bookId } = req.query;
  if (typeof bookId !== 'string') {
    throw new Error('Invalid book ID.');
  }
  const data = req.body as UploadBookPayload['body'];
  const user = req.user;
  if (!user.email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  const updatedBook = await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      const owner = await tx.user.findUnique({
        where: { email: user.email, deletedAt: null, status: 'ACTIVE' },
        include: { assignedRole: true },
      });
      if (!owner) {
        throw new Error('Unauthorized: Owner not found.');
      }
      const isAuthorized = owner.assignedRole.some(
        r => r.role === 'ADMIN' || r.role === 'INSTRUCTOR'
      );
      if (!isAuthorized) {
        throw new Error('Security Violation: Only Admins or Instructors can update books.');
      }
      const category = await tx.bookCategory.findUnique({
        where: { name: data.category },
      });
      if (!category) {
        throw new Error('Invalid Category ID.');
      }
      const existingBook = await tx.book.findUnique({
        where: { id: bookId, deletedAt: null },
        include: { files: true },
      });
      if (!existingBook) {
        throw new Error('Book not found.');
      }
      const isAdmin = owner.assignedRole.some(r => r.role === 'ADMIN');
      if (!isAdmin && existingBook.ownerId !== owner.id) {
        throw new Error('Forbidden: You can only update books that you uploaded.');
      }
      const resolvedAuthor = await resolveBookAuthor(tx, owner, data);
      const updated = await tx.book.update({
        where: { id: bookId },
        data: {
          title: data.title,
          author: resolvedAuthor.authorName,
          authorProfileId: resolvedAuthor.authorProfileId,
          publisher: data.publisher,
          publishYear: Number(data.publishYear),
          ratings: new Decimal(data.ratings),
          translator: data.translator,
          editor: data.editor,
          description: data.description,
          purchaseCost: new Decimal(data.purchaseCost ?? 0),
          physicalRegularPrice: new Decimal(data.physicalRegularPrice ?? 0),
          physicalSalePrice: new Decimal(data.physicalSalePrice ?? 0),
          digitalRegularPrice: new Decimal(data.digitalRegularPrice ?? 0),
          digitalSalePrice: new Decimal(data.digitalSalePrice ?? 0),
          stock: data.stock,
          language: data.language,
          coverImage: data.coverImageUrl,
          isbn: data.isbn,
          edition: data.edition,
          pages: data.pages,
          weight: data.weight,
          metaKeywords: data.metaKeywords,
          metaDescription: data.metaDescription,
          categoryId: category.id,
          status: data.status === 'DRAFT' ? BookStatus.DRAFT : BookStatus.PENDING,
          formats: data.formats.map(f =>
            f === 'Hardcover' ? BookFormat.HARDCOVER : BookFormat.E_BOOK
          ),
          files: {
            create: data.files.map(file => ({
              name: file.name,
              url: file.url,
              fileType: file.fileType,
            })),
          },
        },
        include: {
          files: true,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: owner.id,
          action: 'BOOK_UPDATED',
          entityType: 'BOOK',
          entityId: updated.id,
          changesBefore: JSON.parse(JSON.stringify(existingBook)),
          changesAfter: JSON.parse(JSON.stringify(updated)),
          ipAddress: 'captured-from-request',
        },
      });

      return updated;
    });
  }, 'Update Book');

  return updatedBook.id;
};

const getPublishedBooksByInstructor = async (req: Request) => {
  const instructorId = req.params.instructorId as string;
  if (!instructorId) {
    throw new Error('Instructor ID is required.');
  }

  const books = await executeDbOperation(async prisma => {
    const instructor = await prisma.instructorProfile.findFirst({
      where: {
        userId: instructorId,
        status: ApplicationStatus.APPROVED,
        deletedAt: null,
      },
      select: {
        id: true,
        userId: true,
        authorProfile: {
          select: { id: true },
        },
      },
    });

    if (!instructor) {
      return [];
    }

    return await prisma.book.findMany({
      where: {
        status: BookStatus.APPROVED,
        deletedAt: null,
        OR: [
          // Legacy / instructor-uploaded books.
          { ownerId: instructor.userId },

          // Books attached to this instructor's Author Profile, including
          // books uploaded by an admin on behalf of the instructor.
          ...(instructor.authorProfile?.id
            ? [{ authorProfileId: instructor.authorProfile.id }]
            : []),
        ],
      },
      select: {
        id: true,
        title: true,
        author: true,
        authorProfile: { select: { id: true, name: true, slug: true } },
        coverImage: true,
        physicalRegularPrice: true,
        physicalSalePrice: true,
        digitalRegularPrice: true,
        digitalSalePrice: true,
        formats: true,
        stock: true,
        publisher: true,
        createdAt: true,
        category: {
          select: { name: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }, 'Get Published Books By Instructor');

  // Keep the response shape identical to the public books endpoint so the
  // same BookCard component can be reused in the instructor Books tab.
  return books.map(book => ({
    ...book,
    stock: book.stock > 0 ? 'in-stock' : 'out-of-stock',
  }));
};

const getAllBooksForPublicView = async () => {
  const books = await executeDbOperation(async prisma => {
    return await prisma.book.findMany({
      where: { status: BookStatus.APPROVED, deletedAt: null },
      select: {
        id: true,
        title: true,
        author: true,
        authorProfile: { select: { id: true, name: true, slug: true } },
        coverImage: true,
        physicalRegularPrice: true,
        physicalSalePrice: true,
        digitalRegularPrice: true,
        digitalSalePrice: true,
        formats: true,
        publisher: true,
        createdAt: true,
        stock: true,
        category: {
          select: {
            name: true,
          },
        },
      },
    });
  }, 'Get All Books for Public View');

  return books.map(book => ({
    ...book,
    stock: book.stock > 0 ? 'in-stock' : 'out-of-stock',
  }));
};

const getBookDetailsForPublicView = async (req: Request) => {
  const bookId = req.params.bookId as string;
  if (!bookId) {
    throw new Error('Book ID is required.');
  }
  const book = await executeDbOperation(async prisma => {
    return await prisma.book.findUnique({
      where: { id: bookId, status: BookStatus.APPROVED, deletedAt: null },
      select: {
        id: true,
        title: true,
        author: true,
        authorProfile: {
          select: {
            id: true,
            name: true,
            slug: true,
            photoUrl: true,
            bio: true,
            instructorProfileId: true,
          },
        },
        publisher: true,
        translator: true,
        editor: true,
        description: true,
        physicalRegularPrice: true,
        physicalSalePrice: true,
        digitalRegularPrice: true,
        digitalSalePrice: true,
        stock: true,
        language: true,
        coverImage: true,
        isbn: true,
        edition: true,
        pages: true,
        owner: {
          select: {
            avatarUrl: true,
            status: true,
            instructorProfile: {
              select: {
                displayName: true,
                qualifications: true,
                expertise: true,
              },
            },
          },
        },
        formats: true,
        createdAt: true,
        category: {
          select: {
            name: true,
          },
        },
        files: {
          select: {
            name: true,
            url: true,
            fileType: true,
          },
        },
      },
    });
  }, 'Get Book Details for Public View');

  return book;
};

const getSingleBookForCheckout = async (req: Request) => {
  const bookId = req.params.bookId as string;
  const format = req.query.format as string;

  if (!bookId) {
    throw new Error('Book ID is required.');
  }
  const book = await executeDbOperation(async prisma => {
    return await prisma.book.findUnique({
      where: { id: bookId, status: BookStatus.APPROVED, deletedAt: null },
      select: {
        id: true,
        title: true,
        coverImage: true,
        category: {
          select: {
            name: true,
          },
        },
        weight: true,
        physicalRegularPrice: true,
        physicalSalePrice: true,
        digitalRegularPrice: true,
        digitalSalePrice: true,
        formats: true,
        stock: true,
      },
    });
  }, 'Get Single Book for Checkout');

  if (!book) {
    throw new Error('Book not found or not approved.');
  }

  const requestedFormat = format === 'EBOOK' ? BookFormat.E_BOOK : BookFormat.HARDCOVER;

  if (!book.formats.includes(requestedFormat)) {
    throw new Error(`This book is not available in ${format.toLowerCase()} format.`);
  }

  if (
    book.formats.includes(BookFormat.E_BOOK) &&
    format === 'EBOOK' &&
    book.digitalSalePrice === null
  ) {
    throw new Error('The digital copy of this book is currently unavailable for purchase.');
  }

  if (book.formats.includes(BookFormat.HARDCOVER) && format === 'PHYSICAL' && book.stock <= 0) {
    throw new Error('The physical copy of this book is currently out of stock.');
  }

  return {
    id: book.id,
    title: book.title,
    thumbnailUrl: book.coverImage,
    category: book.category?.name,
    weight: book.weight,
    physicalRegularPrice: book.physicalRegularPrice,
    physicalSalePrice: book.physicalSalePrice,
    digitalRegularPrice: book.digitalRegularPrice,
    digitalSalePrice: book.digitalSalePrice,
    hasDigital: book.formats.includes(BookFormat.E_BOOK),
    stock: book.stock,
  };
};

// User Dashboard

const getAllBooksDataforUser = async (req: Request) => {
  const user = req.user;
  if (!user.email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  const booksData = await executeDbOperation(async prisma => {
    const userProfile = await prisma.user.findUnique({
      where: { email: user.email, deletedAt: null, status: 'ACTIVE' },
      include: { assignedRole: true },
    });

    if (!userProfile) {
      throw new Error('Unauthorized: User profile not found.');
    }

    const isAuthorized = userProfile.assignedRole.some(
      r => r.role === 'STUDENT' || r.role === 'INSTRUCTOR'
    );

    if (!isAuthorized) {
      throw new Error('Security Violation: Only Students and Instructors can access this data.');
    }

    // 2. Query purchased books via OrderItems where the Order status is successful
    const purchasedBookItems = await prisma.orderItem.findMany({
      where: {
        order: {
          userId: userProfile.id,
          status: {
            in: ['PAID', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED'],
          },
        },
        bookId: { not: null },
      },
      select: {
        id: true,
        format: true,
        status: true,
        price: true,
        courierName: true,
        trackingNumber: true,
        shippedAt: true,
        deliveredAt: true,
        createdAt: true,
        order: {
          select: {
            id: true,
            status: true,
            shippingAddress: true,
          },
        },
        book: {
          select: {
            id: true,
            title: true,
            author: true,
            coverImage: true,
            files: {
              select: {
                id: true,
                url: true,
                fileType: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return purchasedBookItems.map(item => {
      const isDigital = item.format === 'DIGITAL';

      return {
        orderItemId: item.id,
        createdAt: item.createdAt,
        orderId: item.order.id,
        orderStatus: item.order.status,
        shippingAddress: isDigital ? null : item.order.shippingAddress,
        book: {
          id: item.book?.id,
          title: item.book?.title,
          coverImage: item.book?.coverImage,
          author: item.book?.author,
          format: item.format,
          price: Number(item.price),
          readUrl: isDigital
            ? (item.book?.files.find(file => file.fileType === 'EBOOK')?.url ??
              item.book?.files.find(file => file.fileType === 'PREVIEW')?.url ??
              null)
            : null,
        },
        delivery: isDigital
          ? null
          : {
              status:
                item.status === 'PENDING' && item.order.status === 'PAID' ? 'PAID' : item.status,
              courierName: item.courierName,
              trackingNumber: item.trackingNumber,
              shippedAt: item.shippedAt,
              deliveredAt: item.deliveredAt,
            },
        downloadUrls: isDigital
          ? (item.book?.files.map(file => ({
              url: file.url,
              action: file.fileType === 'PREVIEW' ? 'READ' : 'DOWNLOAD',
            })) ?? [])
          : null,
        // downloadUrl: isDigital ? item.book?.files.find(file => file.fileType === 'EBOOK')?.url ?? null : null,
      };
    });
  }, 'Get All Purchased Books for Student');

  return booksData;
};

// Admin Dashboard

const getAllBooksDataforAdmin = async (req: Request) => {
  const user = req.user;
  if (!user.email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  const booksData = await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      const userProfile = await tx.user.findUnique({
        where: { email: user.email, deletedAt: null, status: 'ACTIVE' },
        include: { assignedRole: true },
      });

      if (!userProfile) {
        throw new Error('Unauthorized: User profile not found.');
      }
      const isAuthorized = userProfile.assignedRole.some(r => r.role === 'ADMIN');

      if (!isAuthorized) {
        throw new Error('Security Violation: Only Admins can see this data.');
      }

      const stats = await tx.orderItem.aggregate({
        where: {
          book: { deletedAt: null, status: { in: [BookStatus.APPROVED, BookStatus.SUSPENDED] } },
          order: {
            status: OrderStatus.PAID,
          },
        },
        _count: {
          id: true,
        },
        _sum: {
          price: true,
          quantity: true,
        },
      });
      const bookBreakdown = await tx.book.findMany({
        where: { deletedAt: null, status: { in: [BookStatus.APPROVED, BookStatus.SUSPENDED] } },
        select: {
          id: true,
          title: true,
          author: true,
          totalEarning: true,
          purchaseCost: true,
          formats: true,
          physicalRegularPrice: true,
          physicalSalePrice: true,
          digitalRegularPrice: true,
          digitalSalePrice: true,
          stock: true,
          status: true,
          coverImage: true,
          viewCount: true,
          suspendReason: true,
          adminNote: true,
          createdAt: true,
          updatedAt: true,
          category: { select: { id: true, name: true } },
          orderItem: {
            where: {
              order: { status: OrderStatus.PAID },
            },
            select: {
              id: true,
              price: true,
              quantity: true,
              order: { select: { createdAt: true } },
            },
          },
          _count: { select: { reviews: true, wishlistedBy: true } },
        },
        orderBy: { updatedAt: 'desc' },
      });
      bookBreakdown.sort((a, b) => {
        const count = (book: typeof a) =>
          book.orderItem.reduce((sum, item) => sum + item.quantity, 0);
        return count(b) - count(a) || b.updatedAt.getTime() - a.updatedAt.getTime();
      });
      // Count paid orders by order creation date; the schema has no paidAt field.
      // Calendar weeks begin Monday in Bangladesh (UTC+06:00).
      const now = new Date();
      const offset = 6 * 60 * 60 * 1000;
      const local = new Date(now.getTime() + offset);
      const weekday = (local.getUTCDay() + 6) % 7;
      const weekStart =
        Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() - weekday) -
        offset;
      const previousStart = weekStart - 7 * 86400000;
      const emptyWeek = () => ({
        units: 0,
        sales: 0,
        revenue: 0,
        dailyUnits: Array<number>(7).fill(0),
        dailySales: Array<number>(7).fill(0),
        dailyRevenue: Array<number>(7).fill(0),
      });
      const thisWeek = emptyWeek();
      const previousWeek = emptyWeek();
      let totalProfit = 0;
      for (const book of bookBreakdown) {
        for (const item of book.orderItem) {
          const sale = Number(item.price);
          const profit = sale - Number(book.purchaseCost ?? 0) * item.quantity;
          totalProfit += profit;
          const time = item.order.createdAt.getTime();
          const week = time >= weekStart ? thisWeek : time >= previousStart ? previousWeek : null;
          if (!week || time > now.getTime()) {
            continue;
          }
          const start = week === thisWeek ? weekStart : previousStart;
          const day = Math.floor((time - start) / 86400000);
          if (day < 0 || day > 6) {
            continue;
          }
          week.units += item.quantity;
          week.sales += sale;
          week.revenue += profit;
          week.dailyUnits[day] += item.quantity;
          week.dailySales[day] += sale;
          week.dailyRevenue[day] += profit;
        }
      }
      const stockData = await tx.book.aggregate({
        where: { deletedAt: null, status: { in: [BookStatus.APPROVED, BookStatus.SUSPENDED] } },
        _sum: {
          stock: true,
        },
        _count: {
          id: true,
        },
      });

      return {
        totalBooks: stockData._count.id,
        totalSold: stats._sum.quantity ?? 0,
        totalStock: stockData._sum.stock ?? 0,
        totalRevenue: stats._sum.price ?? 0,
        totalProfit,
        salesInsights: { thisWeek, previousWeek },
        bookBreakdown,
      };
    });
  }, 'Get All Books Data for Admin');

  return booksData;
};

const getSingleBookDataForAdminEdit = async (req: Request) => {
  const { bookId } = req.query;
  if (typeof bookId !== 'string') {
    throw new Error('Invalid book ID.');
  }
  const user = req.user;
  if (!user.email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  const bookData = await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      const userProfile = await tx.user.findUnique({
        where: { email: user.email, deletedAt: null, status: 'ACTIVE' },
        include: { assignedRole: true },
      });
      if (!userProfile) {
        throw new Error('Unauthorized: User profile not found.');
      }
      const isAuthorized = userProfile.assignedRole.some(
        r => r.role === 'ADMIN' || r.role === 'INSTRUCTOR'
      );
      if (!isAuthorized) {
        throw new Error('Security Violation: Only Admins and Instructors can see this data.');
      }

      const book = await tx.book.findUnique({
        where: { id: bookId },
        include: {
          files: true,
          category: true,
        },
      });
      if (!book) {
        throw new Error('Book not found.');
      }
      return book;
    });
  }, 'Get Single Book Data for Admin Edit');

  return bookData;
};

const approveBook = async (req: Request) => {
  const { modifiedBookId } = req.query;
  if (typeof modifiedBookId !== 'string') {
    throw new Error('Invalid book ID.');
  }
  const user = req.user;
  if (!user.email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  const approvedBook = await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      const userProfile = await tx.user.findUnique({
        where: { email: user.email, deletedAt: null, status: 'ACTIVE' },
        include: { assignedRole: true },
      });
      if (!userProfile) {
        throw new Error('Unauthorized: User profile not found.');
      }
      const isAuthorized = userProfile.assignedRole.some(r => r.role === 'ADMIN');
      if (!isAuthorized) {
        throw new Error('Security Violation: Only Admins can approve books.');
      }
      const book = await tx.book.findUnique({
        where: { id: modifiedBookId },
      });
      if (!book) {
        throw new Error('Book not found.');
      }
      if (book.status !== BookStatus.PENDING) {
        throw new Error('Only books in PENDING status can be approved.');
      }
      const updatedBook = await tx.book.update({
        where: { id: modifiedBookId },
        data: { status: BookStatus.APPROVED },
      });

      await tx.auditLog.create({
        data: {
          userId: userProfile.id,
          action: 'BOOK_APPROVED',
          entityType: 'BOOK',
          entityId: updatedBook.id,
          changesAfter: JSON.parse(JSON.stringify(updatedBook)),
          ipAddress: 'captured-from-request',
        },
      });

      return updatedBook;
    });
  }, 'Approve Book');

  return approvedBook.id;
};

const updateBookSelling = async (req: Request) => {
  const { bookId } = req.params as { bookId: string };
  const { action, note } = req.body as { action: 'STOP' | 'RESUME'; note: string };

  return await executeDbOperation(
    prisma =>
      prisma.$transaction(async tx => {
        const admin = await getAuthorizedAdmin(tx, req.user.email);
        const book = await tx.book.findFirst({ where: { id: bookId, deletedAt: null } });
        if (!book) {
          throw new Error('Book not found.');
        }
        if (book.status === BookStatus.PENDING) {
          throw new Error('Pending books must be handled from the approvals route.');
        }

        if (action === 'STOP' && book.status !== BookStatus.APPROVED) {
          throw new Error('Only approved books can be stopped.');
        }
        if (action === 'RESUME' && book.status !== BookStatus.SUSPENDED) {
          throw new Error('Only suspended books can resume selling.');
        }

        const nextStatus = action === 'STOP' ? BookStatus.SUSPENDED : BookStatus.APPROVED;
        const updatedBook = await tx.book.update({
          where: { id: bookId },
          data: {
            status: nextStatus,
            suspendReason: action === 'STOP' ? note : null,
            adminNote: note,
          },
        });

        await tx.auditLog.create({
          data: {
            userId: admin.id,
            action: action === 'STOP' ? 'BOOK_SELLING_STOPPED' : 'BOOK_SELLING_RESUMED',
            entityType: 'BOOK',
            entityId: bookId,
            changesBefore: JSON.parse(JSON.stringify(book)),
            changesAfter: JSON.parse(JSON.stringify(updatedBook)),
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
          },
        });
        return updatedBook;
      }),
    'Update Book Selling State'
  );
};

const updateBookStock = async (req: Request) => {
  const { bookId } = req.params as { bookId: string };
  const { stock, note } = req.body as { stock: number; note: string };

  return await executeDbOperation(
    prisma =>
      prisma.$transaction(async tx => {
        const admin = await getAuthorizedAdmin(tx, req.user.email);
        const book = await tx.book.findFirst({ where: { id: bookId, deletedAt: null } });
        if (!book) {
          throw new Error('Book not found.');
        }

        const updatedBook = await tx.book.update({
          where: { id: bookId },
          data: { stock, adminNote: note },
        });
        await tx.auditLog.create({
          data: {
            userId: admin.id,
            action: 'BOOK_STOCK_UPDATED',
            entityType: 'BOOK',
            entityId: bookId,
            changesBefore: { stock: book.stock },
            changesAfter: { stock, note },
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
          },
        });
        return updatedBook;
      }),
    'Update Book Stock'
  );
};

const deleteBook = async (req: Request) => {
  const { bookId } = req.params as { bookId: string };
  const { note } = req.body as { note: string };

  return await executeDbOperation(
    prisma =>
      prisma.$transaction(async tx => {
        const admin = await getAuthorizedAdmin(tx, req.user.email);
        const book = await tx.book.findFirst({ where: { id: bookId, deletedAt: null } });
        if (!book) {
          throw new Error('Book not found.');
        }

        const deletedBook = await tx.book.update({
          where: { id: bookId },
          data: {
            deletedAt: new Date(),
            status: BookStatus.SUSPENDED,
            suspendReason: note,
            adminNote: note,
          },
        });
        await tx.auditLog.create({
          data: {
            userId: admin.id,
            action: 'BOOK_SOFT_DELETED',
            entityType: 'BOOK',
            entityId: bookId,
            changesBefore: JSON.parse(JSON.stringify(book)),
            changesAfter: JSON.parse(JSON.stringify(deletedBook)),
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
          },
        });
        return { id: deletedBook.id };
      }),
    'Soft Delete Book'
  );
};

const createBookCategory = async (req: Request) => {
  const { name, parentId } = req.body as { name: string; parentId?: string | null };
  return await executeDbOperation(
    prisma =>
      prisma.$transaction(async tx => {
        const admin = await getAuthorizedAdmin(tx, req.user.email);
        const category = await tx.bookCategory.create({
          data: { name: name.trim(), slug: toSlug(name), parentId: parentId ?? null },
        });
        await tx.auditLog.create({
          data: {
            userId: admin.id,
            action: 'BOOK_CATEGORY_CREATED',
            entityType: 'BOOK_CATEGORY',
            entityId: category.id,
            changesAfter: JSON.parse(JSON.stringify(category)),
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
          },
        });
        return category;
      }),
    'Create Book Category'
  );
};

const getBookAuthors = async (req: Request) => {
  // Keep requests without a search term compatible with existing consumers.
  const search = typeof req.query.search === 'string' ? req.query.search.trim().slice(0, 100) : '';
  return await executeDbOperation(async prisma => {
    return await prisma.bookAuthor.findMany({
      where: {
        deletedAt: null,
        isActive: true,
        ...(search ? { name: { contains: search, mode: 'insensitive' as const } } : {}),
      },
      select: {
        id: true,
        name: true,
        slug: true,
        photoUrl: true,
        instructorProfileId: true,
      },
      orderBy: { name: 'asc' },
      ...(search ? { take: 20 } : {}),
    });
  }, 'Get Book Authors');
};

const getAdminBookAuthors = async (req: Request) => {
  return await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      await getAuthorizedAdmin(tx, req.user.email);
      return await tx.bookAuthor.findMany({
        where: { deletedAt: null },
        select: {
          id: true,
          name: true,
          slug: true,
          bio: true,
          photoUrl: true,
          websiteUrl: true,
          instructorProfileId: true,
          isActive: true,
          createdAt: true,
          _count: { select: { books: { where: { deletedAt: null } } } },
        },
        orderBy: { name: 'asc' },
      });
    });
  }, 'Get Admin Book Authors');
};

const getAdminBookAuthorDetails = async (req: Request) => {
  const authorId = req.params.authorId as string;
  return await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      await getAuthorizedAdmin(tx, req.user.email);
      const author = await tx.bookAuthor.findFirst({
        where: { id: authorId, deletedAt: null },
        select: {
          id: true,
          name: true,
          slug: true,
          bio: true,
          photoUrl: true,
          websiteUrl: true,
          instructorProfileId: true,
          isActive: true,
          createdAt: true,
          books: {
            where: { deletedAt: null },
            select: {
              id: true,
              title: true,
              status: true,
              coverImage: true,
              formats: true,
              stock: true,
              viewCount: true,
              orderItem: {
                where: { order: { status: OrderStatus.PAID } },
                select: { quantity: true, price: true },
              },
              reviews: {
                where: { deletedAt: null, flagged: false },
                select: { rating: true },
              },
            },
            orderBy: { createdAt: 'desc' },
          },
        },
      });
      if (!author) {
        throw new Error('Author profile not found.');
      }

      const books = author.books.map(book => {
        const unitsSold = book.orderItem.reduce((sum, item) => sum + item.quantity, 0);
        const sales = book.orderItem.reduce((sum, item) => sum + Number(item.price), 0);
        const reviewCount = book.reviews.length;
        const rating = reviewCount
          ? book.reviews.reduce((sum, review) => sum + review.rating, 0) / reviewCount
          : null;
        return {
          id: book.id,
          title: book.title,
          status: book.status,
          coverImage: book.coverImage,
          formats: book.formats,
          stock: book.stock,
          viewCount: book.viewCount,
          unitsSold,
          sales,
          reviewCount,
          rating,
        };
      });
      const reviewCount = books.reduce((sum, book) => sum + book.reviewCount, 0);
      const rating = reviewCount
        ? books.reduce((sum, book) => sum + (book.rating ?? 0) * book.reviewCount, 0) / reviewCount
        : null;
      return {
        id: author.id,
        name: author.name,
        slug: author.slug,
        bio: author.bio,
        photoUrl: author.photoUrl,
        websiteUrl: author.websiteUrl,
        instructorProfileId: author.instructorProfileId,
        isActive: author.isActive,
        createdAt: author.createdAt,
        books,
        stats: {
          bookCount: books.length,
          publishedBooks: books.filter(book => book.status === BookStatus.APPROVED).length,
          unitsSold: books.reduce((sum, book) => sum + book.unitsSold, 0),
          sales: books.reduce((sum, book) => sum + book.sales, 0),
          views: books.reduce((sum, book) => sum + book.viewCount, 0),
          reviewCount,
          rating,
        },
      };
    });
  }, 'Get Admin Author Details');
};

const updateBookAuthor = async (req: Request) => {
  const authorId = req.params.authorId as string;
  const input = req.body as {
    name?: string;
    bio?: string | null;
    photoUrl?: string | null;
    websiteUrl?: string | null;
    isActive?: boolean;
  };
  return await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      const admin = await getAuthorizedAdmin(tx, req.user.email);
      const existing = await tx.bookAuthor.findFirst({
        where: { id: authorId, deletedAt: null },
      });
      if (!existing) {
        throw new Error('Author profile not found.');
      }
      if (input.name && existing.instructorProfileId && input.name !== existing.name) {
        throw new Error('An instructor author name is managed by their instructor profile.');
      }
      const author = await tx.bookAuthor.update({
        where: { id: authorId },
        data: {
          ...(input.name !== undefined ? { name: input.name.trim() } : {}),
          ...(input.bio !== undefined ? { bio: input.bio } : {}),
          ...(input.photoUrl !== undefined ? { photoUrl: input.photoUrl } : {}),
          ...(input.websiteUrl !== undefined ? { websiteUrl: input.websiteUrl } : {}),
          ...(input.isActive !== undefined ? { isActive: input.isActive } : {}),
        },
      });
      // Book rows also store the author as text for legacy and search views.
      if (input.name && input.name.trim() !== existing.name) {
        await tx.book.updateMany({
          where: { authorProfileId: authorId, deletedAt: null },
          data: { author: author.name },
        });
      }
      await tx.auditLog.create({
        data: {
          userId: admin.id,
          action: 'BOOK_AUTHOR_UPDATED',
          entityType: 'BOOK_AUTHOR',
          entityId: authorId,
          changesBefore: JSON.parse(JSON.stringify(existing)),
          changesAfter: JSON.parse(JSON.stringify(author)),
          ipAddress: req.ip,
          userAgent: req.get('user-agent'),
        },
      });
      return author;
    });
  }, 'Update Book Author');
};

const getAuthorCandidates = async (req: Request) => {
  return await executeDbOperation(async prisma => {
    return await prisma.$transaction(async tx => {
      await getAuthorizedAdmin(tx, req.user.email);
      return await tx.instructorProfile.findMany({
        where: {
          deletedAt: null,
          status: ApplicationStatus.APPROVED,
          authorProfile: null,
        },
        select: {
          id: true,
          userId: true,
          displayName: true,
          bio: true,
          website: true,
          user: { select: { avatarUrl: true } },
        },
        orderBy: { displayName: 'asc' },
      });
    });
  }, 'Get Instructor Author Candidates');
};

const createBookAuthor = async (req: Request) => {
  const { name, instructorProfileId, bio, photoUrl, websiteUrl } = req.body as {
    name?: string;
    instructorProfileId?: string;
    bio?: string;
    photoUrl?: string;
    websiteUrl?: string;
  };

  return await executeDbOperation(
    prisma =>
      prisma.$transaction(async tx => {
        const admin = await getAuthorizedAdmin(tx, req.user.email);

        let authorName = name?.trim();
        let resolvedBio = bio;
        let resolvedPhotoUrl = photoUrl;
        let resolvedWebsiteUrl = websiteUrl;

        if (instructorProfileId) {
          const instructor = await tx.instructorProfile.findFirst({
            where: {
              id: instructorProfileId,
              status: ApplicationStatus.APPROVED,
              deletedAt: null,
            },
            select: {
              id: true,
              displayName: true,
              bio: true,
              website: true,
              user: { select: { avatarUrl: true } },
              authorProfile: { select: { id: true } },
            },
          });

          if (!instructor) {
            throw new Error('Instructor profile not found or is not approved.');
          }
          if (instructor.authorProfile) {
            throw new Error('This instructor already has an author profile.');
          }

          authorName = instructor.displayName;
          resolvedBio = bio ?? instructor.bio;
          resolvedPhotoUrl = photoUrl ?? instructor.user.avatarUrl ?? undefined;
          resolvedWebsiteUrl = websiteUrl ?? instructor.website ?? undefined;
        }

        if (!authorName) {
          throw new Error('Author name is required.');
        }

        const slug = await uniqueAuthorSlug(tx, authorName);
        const author = await tx.bookAuthor.create({
          data: {
            name: authorName,
            slug,
            instructorProfileId: instructorProfileId ?? null,
            bio: resolvedBio,
            photoUrl: resolvedPhotoUrl,
            websiteUrl: resolvedWebsiteUrl,
          },
        });

        // Legacy instructor books only stored the name string. When an instructor is
        // explicitly linked as an author, attach their existing uploaded books too.
        if (instructorProfileId) {
          const instructor = await tx.instructorProfile.findUnique({
            where: { id: instructorProfileId },
            select: { userId: true },
          });
          if (instructor) {
            await tx.book.updateMany({
              where: {
                ownerId: instructor.userId,
                authorProfileId: null,
                deletedAt: null,
              },
              data: {
                authorProfileId: author.id,
                author: author.name,
              },
            });
          }
        }

        await tx.auditLog.create({
          data: {
            userId: admin.id,
            action: 'BOOK_AUTHOR_CREATED',
            entityType: 'BOOK_AUTHOR',
            entityId: author.id,
            changesAfter: JSON.parse(JSON.stringify(author)),
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
          },
        });
        return author;
      }),
    'Create Book Author'
  );
};

const getPublicAuthorProfile = async (req: Request) => {
  const slug = req.params.slug as string;
  if (!slug) {
    throw new Error('Author slug is required.');
  }

  return await executeDbOperation(async prisma => {
    const author = await prisma.bookAuthor.findFirst({
      where: { slug, deletedAt: null, isActive: true },
      select: {
        id: true,
        name: true,
        slug: true,
        bio: true,
        photoUrl: true,
        websiteUrl: true,
        instructorProfileId: true,
        books: {
          where: { status: BookStatus.APPROVED, deletedAt: null },
          select: {
            id: true,
            title: true,
            author: true,
            coverImage: true,
            physicalRegularPrice: true,
            physicalSalePrice: true,
            digitalRegularPrice: true,
            digitalSalePrice: true,
            formats: true,
            stock: true,
            publisher: true,
            category: { select: { name: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        instructorProfile: {
          select: {
            userId: true,
            displayName: true,
            expertise: true,
            bio: true,
            website: true,
            user: { select: { avatarUrl: true } },
            ownedCourses: {
              where: { status: 'PUBLISHED', deletedAt: null },
              select: {
                id: true,
                title: true,
                slug: true,
                thumbnailUrl: true,
                originalPrice: true,
                discountPrice: true,
                ratingAverage: true,
                enrollmentCount: true,
                category: { select: { name: true } },
              },
              orderBy: { createdAt: 'desc' },
            },
          },
        },
      },
    });

    if (!author) {
      return null;
    }

    return {
      ...author,
      photoUrl: author.photoUrl ?? author.instructorProfile?.user.avatarUrl ?? null,
      bio: author.bio ?? author.instructorProfile?.bio ?? null,
      websiteUrl: author.websiteUrl ?? author.instructorProfile?.website ?? null,
      instructor: author.instructorProfile
        ? {
            userId: author.instructorProfile.userId,
            displayName: author.instructorProfile.displayName,
            expertise: author.instructorProfile.expertise,
          }
        : null,
      courses: author.instructorProfile?.ownedCourses ?? [],
      instructorProfile: undefined,
    };
  }, 'Get Public Author Profile');
};

// Instructor Dashboard. Every query is scoped to the authenticated owner.
const getAllBooksDataForInstructor = async (req: Request) => {
  const email = req.user.email;
  if (!email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  return await executeDbOperation(async prisma => {
    const instructor = await prisma.user.findUnique({
      where: { email, deletedAt: null, status: 'ACTIVE' },
      include: { assignedRole: true },
    });
    if (!instructor || !instructor.assignedRole.some(role => role.role === 'INSTRUCTOR')) {
      throw new Error('Security Violation: Only instructors can access this data.');
    }

    const ownerFilter = { ownerId: instructor.id, deletedAt: null };
    const [sales, stock, bookBreakdown] = await Promise.all([
      prisma.orderItem.aggregate({
        where: {
          book: ownerFilter,
          order: { status: OrderStatus.PAID },
        },
        _count: { id: true },
        _sum: { price: true },
      }),
      prisma.book.aggregate({
        where: ownerFilter,
        _sum: { stock: true },
        _count: { id: true },
      }),
      prisma.book.findMany({
        where: ownerFilter,
        select: {
          id: true,
          title: true,
          author: true,
          formats: true,
          physicalRegularPrice: true,
          physicalSalePrice: true,
          digitalRegularPrice: true,
          digitalSalePrice: true,
          stock: true,
          status: true,
          createdAt: true,
          orderItem: {
            where: { order: { status: OrderStatus.PAID } },
            select: { id: true, price: true },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
    ]);

    return {
      totalBooks: stock._count.id,
      totalSold: sales._count.id,
      totalStock: stock._sum.stock ?? 0,
      totalRevenue: sales._sum.price ?? 0,
      bookBreakdown: bookBreakdown.map(book => ({
        ...book,
        totalEarning: book.orderItem.reduce((sum, item) => sum + Number(item.price), 0),
      })),
    };
  }, 'Get All Books Data for Instructor');
};

const getSingleBookDataForInstructorEdit = async (req: Request) => {
  const bookId = req.query.bookId;
  const email = req.user.email;
  if (typeof bookId !== 'string') {
    throw new Error('Invalid book ID.');
  }
  if (!email) {
    throw new Error('Unauthorized: User not authenticated.');
  }

  return await executeDbOperation(async prisma => {
    const instructor = await prisma.user.findUnique({
      where: { email, deletedAt: null, status: 'ACTIVE' },
      include: { assignedRole: true },
    });
    if (!instructor || !instructor.assignedRole.some(role => role.role === 'INSTRUCTOR')) {
      throw new Error('Security Violation: Only instructors can edit their books.');
    }

    const book = await prisma.book.findFirst({
      where: { id: bookId, ownerId: instructor.id, deletedAt: null },
      include: { files: true, category: true },
    });
    if (!book) {
      throw new Error('Book not found or you do not have permission to edit it.');
    }
    return book;
  }, 'Get Single Book Data for Instructor Edit');
};

export const bookService = {
  getBooksCategories,
  getPublishedBooksByInstructor,
  uploadBook,
  bulkUploadBooks,
  updateBook,
  getAllBooksDataforAdmin,
  getSingleBookDataForAdminEdit,
  approveBook,
  updateBookSelling,
  updateBookStock,
  deleteBook,
  createBookCategory,
  createBookAuthor,
  getBookAuthors,
  getAdminBookAuthors,
  getAdminBookAuthorDetails,
  updateBookAuthor,
  getAuthorCandidates,
  getPublicAuthorProfile,
  getAllBooksForPublicView,
  getBookDetailsForPublicView,
  getAllBooksDataforUser,
  getSingleBookForCheckout,
  getAllBooksDataForInstructor,
  getSingleBookDataForInstructorEdit,
};
